Repair Notes fixes formatting/shell/print/path defects without rebuilding content.
No Unit Bank is required for a normal repair.
Current shell authority packaged by the Control Panel: pms_build/4_Build_Notes_PM.zip.
Use the Maintenance tab, select the deployed target, describe the defect if needed, save the request ZIP, then upload it.
