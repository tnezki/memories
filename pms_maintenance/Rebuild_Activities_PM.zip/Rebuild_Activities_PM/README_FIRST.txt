Activities rebuild pilot.

Current delegated Build PM: pms_build/6_Build_Activities_PM.zip
Bank required: yes
Scopes: section, unit, multiple_units, whole_course
Output: rebuilt Activities in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
