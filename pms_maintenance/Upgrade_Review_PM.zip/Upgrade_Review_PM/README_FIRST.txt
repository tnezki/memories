Targeted Review maintenance. The embedded Base Recurring + Assessment PM is the sole renderer owner. Returns replacement ZIP + inspection-only preview ZIP with CSS.
