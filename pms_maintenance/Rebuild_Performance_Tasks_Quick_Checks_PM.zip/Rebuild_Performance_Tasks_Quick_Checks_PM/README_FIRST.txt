Performance Tasks & Quick Checks rebuild pilot.

Current delegated Build PM: pms_build/14_Build_Performance_Tasks_Quick_Checks_PM.zip
Bank required: no
Scopes: section, unit, multiple_units, whole_course
Output: rebuilt Performance Task & Quick Check branches

Use through the Curriculum Control Panel Maintenance tab when possible.
