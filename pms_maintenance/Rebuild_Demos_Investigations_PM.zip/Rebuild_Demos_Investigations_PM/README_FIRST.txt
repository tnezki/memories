Demos & Investigations rebuild pilot.

Current delegated Build PM: pms_build/13_Build_Demos_Investigations_PM.zip
Bank required: no
Scopes: section, unit, multiple_units, whole_course
Output: rebuilt Demos & Investigations branches

Use through the Curriculum Control Panel Maintenance tab when possible.
