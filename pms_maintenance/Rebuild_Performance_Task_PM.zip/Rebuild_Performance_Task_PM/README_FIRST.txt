Individual Performance Task rebuild pilot.

Current delegated Build PM: pms_build/14_Build_Performance_Tasks_Quick_Checks_PM.zip
Bank required: no
Scopes: item, section
Output: rebuilt selected Performance Task in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
