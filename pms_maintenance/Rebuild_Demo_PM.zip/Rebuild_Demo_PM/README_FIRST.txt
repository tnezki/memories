Individual Demo rebuild pilot.

Current delegated Build PM: pms_build/13_Build_Demos_Investigations_PM.zip
Bank required: no
Scopes: item, section
Output: rebuilt selected Demo in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
