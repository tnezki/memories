3h - Mathematical Notation & Expression Hygiene Upgrade v1.2

Use current Framework + finalized Unit Bank + this PM ZIP.
Prompt: Carefully read PM and Run.

New in v1.2: system-row MathJax repair and embedded ~fix_mathjax_v11.py.
