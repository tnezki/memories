Exit Tickets rebuild pilot.

Current delegated Build PM: pms_build/12_Build_Pract_to_Sum_PM.zip
Bank required: yes
Scopes: item, section, unit, multiple_units, whole_course
Output: rebuilt Exit Tickets in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
