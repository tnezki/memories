UPGRADE EXIT TICKETS PM — v1.2
==============================

Use this Maintenance PM to convert existing Exit Tickets to the approved dual-use format:
projector Ticket A/B/C plus four print/collect versions of each ticket.

Per Ticket:
- Version 1 uses all four finalized Bank questions exactly.
- Bank Q1 is the common Anchor and appears exactly on all four versions.
- Bank Q2 and Q3 generate tight number/value-switch parallels for Versions 2–4.
- Bank Q4 generates a controlled evidence-aligned variation for Versions 2–4.
- All four evidence roles are scrambled with a balanced 4x4 rotation so each role appears once in each displayed question position across Versions 1–4.
- Each print version is two portrait pages with two questions per page.

This PM intentionally requires the current Unit Bank and never modifies it.

Systemic run-time bottlenecks are reported through PM_IMPROVEMENT_REPORT.txt; proposed PM upgrades remain non-authoritative until teacher approval.
