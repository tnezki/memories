Practice rebuild pilot.

Current delegated Build PM: pms_build/5_Build_Practice_PM.zip
Bank required: yes
Scopes: section, unit, multiple_units, whole_course
Output: rebuilt Practice family in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
