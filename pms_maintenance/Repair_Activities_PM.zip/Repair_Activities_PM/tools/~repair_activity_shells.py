#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, json, re, sys
from pathlib import Path
from bs4 import BeautifulSoup

CHECK_PREFIX_RE = re.compile(r"^\s*(?:```html\s*|html\s*)(?=(?:<!doctype\s+html\b|<html\b))", re.I)


def norm_text(s):
    return re.sub(r"\s+", " ", s or "").strip()


def file_kind(path: Path):
    n=path.name.lower()
    if n.endswith('_stations.html'): return 'stations'
    if n.endswith('_questions_solutions.html'): return 'projected'
    if 'find_someone_who' in n: return 'fsw'
    if n.endswith('_act1.html'): return 'hub'
    return 'other'


def protected_signature(path: Path):
    raw=path.read_text(encoding='utf-8',errors='replace')
    soup=BeautifulSoup(raw,'html.parser')
    kind=file_kind(path)
    data={'kind':kind}
    # Mathematical/content-bearing nodes. Headers/workspace shells are intentionally excluded.
    data['bank_ids']=[x.get('data-bank-id','') for x in soup.select('[data-bank-id]')]
    data['images']=[x.get('src','') for x in soup.find_all('img')]
    data['tables']=[[norm_text(td.get_text(' ',strip=True)) for td in t.find_all(['th','td'])] for t in soup.find_all('table')]
    if kind=='projected':
        data['questions']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('.prob-q')]
        data['solutions']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('.solution')]
    elif kind=='stations':
        data['questions']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('.station-problem .question')]
        data['solutions']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('.solution-item')]
    elif kind=='hub':
        # Exclude headers/nav wrappers but protect the authored direction/moves text.
        data['moves']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('#teacher-student-moves .dir-text, #teacher-student-moves li')]
        data['directions']=[norm_text(x.get_text(' ',strip=True)) for x in soup.select('.dir-body')]
    elif kind=='fsw':
        # Full-byte preservation is handled by skipping this file entirely.
        data['full']=hashlib.sha256(raw.encode('utf-8')).hexdigest()
    return json.dumps(data,sort_keys=True,ensure_ascii=False)


def ensure_stylesheet(soup, href):
    links=soup.find_all('link',rel=lambda v: v and 'stylesheet' in v)
    if any(x.get('href')==href for x in links): return
    tag=soup.new_tag('link',rel='stylesheet',href=href)
    if soup.head: soup.head.append(tag)


def remove_obsolete_activity_links(soup):
    obsolete={'../../css/activity_stations.css','../../css/activity_find_someone_who.css'}
    for link in list(soup.find_all('link',rel=lambda v:v and 'stylesheet' in v)):
        if link.get('href') in obsolete: link.decompose()


def parse_identity(path: Path, soup):
    n=path.name.lower()
    m=re.search(r'u(\d+)_(\d+)_set(\d+)',n)
    if m:
        u=int(m.group(1)); secnum=m.group(2); setn=int(m.group(3)); return u,f'{u}.{secnum}',setn
    title=soup.title.get_text(' ',strip=True) if soup.title else ''
    m=re.search(r'Unit\s+(\d+)\s+Section\s+([0-9.]+).*?Set\s+(\d+)',title,re.I)
    if m: return int(m.group(1)),m.group(2),int(m.group(3))
    return None,None,None


def repair_projected(path: Path, soup):
    u,sec,setn=parse_identity(path,soup)
    if not (u and sec and setn):
        raise ValueError(f'{path}: cannot resolve Unit/Section/Set from filename/title')
    pages=soup.select('section.page.question-page, section.page.solution-page')
    for idx,page in enumerate(pages,1):
        typ='Question' if 'question-page' in (page.get('class') or []) else 'Solution'
        head=page.select_one(':scope > .prob-head')
        if not head:
            head=soup.new_tag('div',attrs={'class':'prob-head'})
            page.insert(0,head)
        num=head.select_one('.prob-num')
        prob=None
        if num:
            m=re.search(r'(\d+)',num.get_text(' ',strip=True)); prob=int(m.group(1)) if m else None
        if prob is None:
            # Question/Solution pages alternate; derive stable problem number from matching Bank-ID occurrence.
            bid=page.get('data-bank-id','')
            same=[x for x in pages if x.get('data-bank-id','')==bid] if bid else []
            if bid:
                ordered=[]
                for x in pages:
                    b=x.get('data-bank-id','')
                    if b and b not in ordered: ordered.append(b)
                prob=ordered.index(bid)+1 if bid in ordered else idx
            else:
                prob=(idx+1)//2
        head.clear()
        left=soup.new_tag('span'); left.string=f'Unit {u} • Section {sec} • Set {setn} • Problem {prob}'
        right=soup.new_tag('span'); right.string=typ
        head.extend([left,right])


def new_blank_page(soup, cls):
    return soup.new_tag('section',attrs={'class':f'page {cls} duplex-blank'})


def station_number_from_header(page, fallback):
    h=page.find(class_='header')
    text=norm_text(h.get_text(' ',strip=True)) if h else ''
    m=re.search(r'Station\s+(\d+)',text,re.I)
    return int(m.group(1)) if m else fallback


def build_station_header(soup,page,station,setn,solutions=False):
    oldh=page.find(class_='header')
    oldcopy=page.find(class_='copy-note')
    if oldh: oldh.decompose()
    if oldcopy: oldcopy.decompose()
    h=soup.new_tag('div',attrs={'class':'header'})
    h.string=f"Station {station} Solutions • Set {setn}" if solutions else f"Station {station} • Set {setn}"
    c=soup.new_tag('div',attrs={'class':'copy-note'})
    c.string='Answer Key' if solutions else 'Classroom Copy 1'
    page.insert(0,c); page.insert(0,h)


def repair_stations(path: Path, soup):
    u,sec,setn=parse_identity(path,soup)
    if not (u and sec and setn):
        raise ValueError(f'{path}: cannot resolve Unit/Section/Set')
    ensure_stylesheet(soup,'../../css/base.css')
    remove_obsolete_activity_links(soup)
    ensure_stylesheet(soup,'../../css/activities/activity_stations.css')

    if not soup.body: raise ValueError(f'{path}: missing body')
    wrap=soup.body.find('div',class_='wrap',recursive=False)
    if wrap is None:
        wrap=soup.new_tag('div',attrs={'class':'wrap'})
        for child in list(soup.body.contents):
            if getattr(child,'name',None) is not None or str(child).strip(): wrap.append(child.extract())
        soup.body.append(wrap)

    pages=wrap.find_all('section',class_='page',recursive=False)
    qpages=[p for p in pages if 'station-question-page' in (p.get('class') or [])]
    answer_pages=[p for p in pages if 'station-answer-page' in (p.get('class') or [])]
    if not qpages: raise ValueError(f'{path}: no station question pages')

    # Snapshot solution items by station before rebuilding solution pagination.
    solution_groups=[]
    page_index=0
    while page_index < len(answer_pages):
        p=answer_pages[page_index]
        station=station_number_from_header(p,len(solution_groups)+1)
        items=[]
        # collect until next apparent station solution page-1, but current format is exactly two pages.
        for candidate in answer_pages[page_index:page_index+2]:
            items.extend([copy.copy(x) for x in candidate.select('.solution-list > .solution-item')])
        solution_groups.append((station,items))
        page_index += 2

    # Remove all current page children; rebuild stable duplex order from preserved nodes.
    for p in list(wrap.find_all('section',class_='page',recursive=False)): p.extract()

    for i,page in enumerate(qpages,1):
        station=station_number_from_header(page,i)
        build_station_header(soup,page,station,setn,solutions=False)
        # No student workspace on traveling Station prompts.
        for selector in ['.work','.workspace','.answer-space','.response-space','.student-work']:
            for x in page.select(selector): x.decompose()
        for fig in page.find_all('figure'):
            if fig.find('img'):
                cls=[c for c in (fig.get('class') or []) if c!='graph-block']
                if 'figure' not in cls: cls.append('figure')
                fig['class']=cls
        wrap.append(page)
        wrap.append(new_blank_page(soup,'station-blank-page'))

    # Rebuild each Station solution as exactly two pages. Four normal items => 2 + 2.
    group_map={n:items for n,items in solution_groups}
    for i,q in enumerate(qpages,1):
        station=station_number_from_header(q,i)
        items=group_map.get(station,[])
        if not items:
            raise ValueError(f'{path}: no solutions found for Station {station}')
        # Split as evenly as possible across two pages, preserving order.
        cut=(len(items)+1)//2
        parts=[items[:cut],items[cut:]]
        for page_no,part in enumerate(parts,1):
            p=soup.new_tag('section',attrs={'class':f'page station-answer-page station-solution-page-{page_no}'})
            build_station_header(soup,p,station,setn,solutions=True)
            lst=soup.new_tag('div',attrs={'class':'solution-list'})
            for item in part: lst.append(item)
            p.append(lst)
            foot=soup.new_tag('div',attrs={'class':'page-footer'}); foot.string=f'Unit {u} • Section {sec}'
            p.append(foot)
            wrap.append(p)


def repair_file(path: Path):
    kind=file_kind(path)
    raw=path.read_text(encoding='utf-8',errors='replace')
    if kind=='fsw': return False  # default freeze
    before=protected_signature(path)
    raw=CHECK_PREFIX_RE.sub('',raw,count=1)
    soup=BeautifulSoup(raw,'html.parser')
    if kind=='projected':
        ensure_stylesheet(soup,'../../css/base.css'); ensure_stylesheet(soup,'../../css/activities.css')
        repair_projected(path,soup)
    elif kind=='stations':
        repair_stations(path,soup)
    elif kind=='hub':
        ensure_stylesheet(soup,'../../css/base.css'); ensure_stylesheet(soup,'../../css/activities.css')
        options=soup.select_one('section#activity-options.page')
        moves=soup.select_one('section#teacher-student-moves.page')
        if options and moves and options.find_next_sibling('section') is not moves:
            moves.extract(); options.insert_after(moves)
    else:
        # Only prefix cleanup for unrecognized Activity HTML; do not reinterpret it.
        pass
    out=str(soup)
    if not re.match(r'(?is)^\s*<!doctype\s+html\b',out): out='<!DOCTYPE html>\n'+out
    path.write_text(out,encoding='utf-8')
    after=protected_signature(path)
    if before!=after:
        raise RuntimeError(f'{path}: protected mathematical/content signature changed')
    return True


def audit(root: Path):
    errors=[]
    for p in root.rglob('*.html'):
        kind=file_kind(p)
        raw=p.read_text(encoding='utf-8',errors='replace')
        if CHECK_PREFIX_RE.match(raw): errors.append(f'{p}: raw html/fence prefix remains')
        if kind=='projected':
            s=BeautifulSoup(raw,'html.parser')
            for j,page in enumerate(s.select('section.page.question-page, section.page.solution-page'),1):
                h=page.select_one(':scope > .prob-head')
                txt=norm_text(h.get_text(' ',strip=True)) if h else ''
                if not re.search(r'Unit\s+\d+\s+•\s+Section\s+[0-9.]+\s+•\s+Set\s+\d+\s+•\s+Problem\s+\d+',txt):
                    errors.append(f'{p}: projected page {j} missing full context header')
        if kind=='stations':
            s=BeautifulSoup(raw,'html.parser')
            wrap=s.body.find('div',class_='wrap',recursive=False) if s.body else None
            if not wrap: errors.append(f'{p}: missing direct .wrap'); continue
            pages=wrap.find_all('section',class_='page',recursive=False)
            q=[x for x in pages if 'station-question-page' in (x.get('class') or [])]
            a=[x for x in pages if 'station-answer-page' in (x.get('class') or [])]
            if len(a)!=2*len(q): errors.append(f'{p}: solutions must be exactly two pages per Station')
            seen_solution=False
            for idx,page in enumerate(pages):
                cls=page.get('class') or []
                if 'station-answer-page' in cls: seen_solution=True
                if 'station-question-page' in cls:
                    if seen_solution: errors.append(f'{p}: Station prompt appears after solutions')
                    h=page.select_one(':scope > .header')
                    if not h or not re.search(r'^Station\s+\d+\s+•\s+Set\s+\d+$',norm_text(h.get_text(' ',strip=True))):
                        errors.append(f'{p}: Station prompt header incorrect')
                    if h and h.find('h1'): errors.append(f'{p}: nested h1 in Station header')
                    if page.select('.work,.workspace,.answer-space,.response-space,.student-work'):
                        errors.append(f'{p}: Station prompt contains workspace element')
                    if idx+1>=len(pages) or 'station-blank-page' not in (pages[idx+1].get('class') or []):
                        errors.append(f'{p}: Station prompt not immediately followed by blank back')
                if 'station-answer-page' in cls:
                    h=page.select_one(':scope > .header')
                    if not h or 'Solutions' not in norm_text(h.get_text(' ',strip=True)):
                        errors.append(f'{p}: solution page missing visible Station Solutions header')
            # Normal four-problem Station should be 2+2.
            for i in range(0,len(a),2):
                pair=a[i:i+2]
                if len(pair)==2:
                    counts=[len(x.select('.solution-list > .solution-item')) for x in pair]
                    total=sum(counts)
                    if total==4 and counts!=[2,2]: errors.append(f'{p}: four-solution Station must split 2+2, got {counts}')
    return errors


def main():
    ap=argparse.ArgumentParser(description='Repair Activity shell/layout defects without changing protected math/content.')
    ap.add_argument('root')
    ap.add_argument('--audit-only',action='store_true')
    args=ap.parse_args()
    root=Path(args.root)
    if not root.exists(): raise SystemExit(f'Not found: {root}')
    changed=0
    if not args.audit_only:
        for p in root.rglob('*.html'):
            if repair_file(p): changed+=1
    errors=audit(root)
    if errors:
        print('\n'.join('ERROR: '+e for e in errors))
        raise SystemExit(1)
    print(f'Repair Activities shell audit: PASS ({changed} file(s) normalized)')

if __name__=='__main__': main()
