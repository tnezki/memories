Review + Review Practice rebuild pilot.

Current delegated Build PM: pms_build/10_Build_Review_PM.zip
Bank required: yes
Scopes: unit, multiple_units, whole_course
Output: rebuilt Review + Review Practice in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
