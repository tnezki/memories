3l Upgrade Physics Bank — Cross-Resource Freshness — v2.0

PURPOSE
-------
cross-resource same-work duplication/freshness only.

CHAIN CONTRACT
--------------
Input one COMPLETE current Physics Unit Bank ZIP.
Return one COMPLETE updated Physics Unit Bank ZIP.
The returned ZIP is intended to be passed directly into a fresh chat with the next PM.
Do not return a sparse REPO_PATCH unless the teacher explicitly says the upgrade chain is ending and asks for repository delivery.

Every edited item must preserve and resolve its existing `i_can_id` against the current Physics Framework / Unit I-can map.

Run command:
  Carefully read PM and Run.
