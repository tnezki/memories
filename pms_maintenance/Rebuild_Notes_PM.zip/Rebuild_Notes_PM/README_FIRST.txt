Notes rebuild pilot.

Current delegated Build PM: pms_build/4_Build_Notes_PM.zip
Bank required: yes
Scopes: section, unit, multiple_units, whole_course
Output: rebuilt Notes in the same deployment structure

Use through the Curriculum Control Panel Maintenance tab when possible.
