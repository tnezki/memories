CANONICAL ACTIVITIES HTML REFERENCES
===================================

These references preserve four approved Activity DOM families:
- activity_hub_reference.html
- questions_solutions_reference.html
- stations_reference.html
- find_someone_who_reference.html

Use the matching shell only when the current Framework selects that Activity structure. The examples are layout
references, not question-content authority. Question sets come from the finalized Bank and course-specific
selection/routing comes from the Framework. Do not force every Activity into one shell.

LOCKED SHELL DETAILS (v1.7)
---------------------------
- Find Someone Who preserves signature lines + student workspaces and uses 3 student problems/page, 4 key problems/page (24 items => 8 + 6 pages).
- Projection Questions/Solutions image figures use `graph-block`.
- Stations preserve representations on both question and answer copies.
- Descriptive figcaptions are omitted.

GENERIC RUN
Use exactly: `Carefully read PM and Run.`
The current PM package determines the operation; do not paste an older resource-specific prompt.
