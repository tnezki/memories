#!/usr/bin/env python3
from pathlib import Path
from bs4 import BeautifulSoup
import math, sys

root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]; checks=0

def fail(msg): errors.append(msg)
def check(cond,msg):
    global checks
    checks += 1
    if not cond: fail(msg)

def soup(p): return BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
def reps(node):
    return (len(node.find_all('table')), len(node.find_all('img')), len(node.find_all('svg')))

for p in root.rglob('*.html'):
    s=soup(p); name=p.name.lower()
    # Philosophy / shell rule: no descriptive figure captions in Activities output.
    check(not s.find('figcaption'), f'{p}: descriptive figcaption present')

    if 'questions_solutions' in name:
        for fig in s.select('.prob-q figure'):
            if fig.find('img'):
                check('graph-block' in (fig.get('class') or []), f'{p}: projection image figure must use graph-block')

    if 'find_someone_who' in name:
        spages=s.select('section.student-worksheet-page')
        kpages=s.select('section.teacher-key-page')
        sprobs=s.select('.student-problem')
        kprobs=s.select('.teacher-key-page .answer-problem')
        check(bool(sprobs), f'{p}: no student problems found')
        check(len(spages)==math.ceil(len(sprobs)/3), f'{p}: student page count must be ceil(items/3)')
        check(len(kpages)==math.ceil(len(kprobs)/4), f'{p}: key page count must be ceil(items/4)')
        for i,node in enumerate(sprobs,1):
            check(bool(node.select_one('.signature-line')), f'{p}: student problem {i} missing signature-line')
            check(bool(node.select_one('.workspace-label')), f'{p}: student problem {i} missing workspace-label')
            check(bool(node.select_one('.workspace')), f'{p}: student problem {i} missing workspace')

    if 'stations' in name:
        # Match representations by bank id where traceability ids exist.
        q={}
        a={}
        for node in s.select('.station-question-page [data-bank-id], .station-problem[data-bank-id]'):
            q.setdefault(node.get('data-bank-id'), []).append(reps(node))
        for node in s.select('.station-answer-page [data-bank-id], .solution-item[data-bank-id]'):
            a.setdefault(node.get('data-bank-id'), []).append(reps(node))
        for bid in set(q)&set(a):
            check(any(r in a[bid] for r in q[bid]), f'{p}: station representation dropped for {bid}')

print(f'ACTIVITY_SHELL_CHECKS={checks}')
print(f'ERRORS={len(errors)}')
for e in errors: print('ERROR:',e)
sys.exit(1 if errors else 0)
