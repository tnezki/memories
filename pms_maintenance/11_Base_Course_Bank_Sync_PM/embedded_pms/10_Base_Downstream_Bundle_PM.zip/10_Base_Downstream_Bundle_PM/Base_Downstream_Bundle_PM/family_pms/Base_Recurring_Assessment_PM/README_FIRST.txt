BASE RECURRING + ASSESSMENT RESOURCES PM STARTER v1.8
=====================================================

Use this ONE Starter for Warm-Ups, Exit Tickets, Progress Trackers, Reviews, and Summative Assessments.

Fresh-chat uploads:
  1. 7_Base_Recurring_Assessment_PM.zip
  2. current Course Framework ZIP
  3. finalized requested Unit Bank ZIP

Do not upload a separate Curriculum Philosophy; it is bundled here.
Do not upload separate CSS; the approved CSS references are bundled here.
Do not upload the Assessment Plan separately when the current Framework embeds it.

The Framework owns course-specific counts, routing, paths, names, and assessment family.
This Base PM owns universal extraction/rendering/package mechanics.

The css/ folder is a reference/install-once library. Ordinary Unit resource ZIPs link to the deployed course-root CSS and do not duplicate CSS.


v1.2 WARM-UP CORRECTION
------------------------
Locked the tested Notability Warm-Up HTML: simple Section/Day header only; no kicker/subtitle/name/date; no visible workspace element. Blank card area is the writing space.




v1.4 PHYSICS SUMMATIVE TAIL + ZIP DELIVERY CORRECTION
------------------------------------------------------
Locked the approved final-two-page Physics layout: `.page.answersheet` followed by the current `.fr-sheet-page` / `.fr-sheet-table` 2x2 work sheet for 17–20. Legacy `.frgrid` remains CSS compatibility only and is prohibited in new builds. Added source-vs-output representation preservation checks and made a real ZIP archive the required final deliverable.

v1.3 SUMMATIVE STALE-TEMPLATE + PHYSICS BUBBLE CORRECTION
---------------------------------------------------------
Current Framework + finalized Bank own the active Summative form IDs. Old rendered HTML can never add forms; answer-sheet selectors are generated from the active IDs. Physics bubble sheets use separate CSS circle elements so letters stay normal-sized while bubbles remain easy to mark.


v1.6 CANONICAL HTML SHELL UPDATE
- Added tested Warm-Up, Exit Ticket, Progress Tracker, Review, Review Practice references.
- Added secure-content-free Algebra/Calculus Summative DOM shell.
- Bundled Philosophy synced to v3.3 and pre-ZIP MathJax v10 gate is explicit.

v1.8 SUMMATIVE SHELL-ENFORCEMENT UPDATE
- Locked math Summative size classes to q-compact/q-standard/q-large/q-xlarge.
- Locked image wrapper classes to figure-block + question-graph.
- Locked ordinary data tables to data-table/approved styled class.
- Added deterministic shell-contract checker.

GENERIC RUN
Use exactly: `Carefully read PM and Run.`
The current PM package determines the operation; do not paste an older resource-specific prompt.
