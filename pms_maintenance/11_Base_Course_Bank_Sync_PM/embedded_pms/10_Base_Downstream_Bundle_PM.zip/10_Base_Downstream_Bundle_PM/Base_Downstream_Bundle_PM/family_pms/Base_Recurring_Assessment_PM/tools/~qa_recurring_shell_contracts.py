#!/usr/bin/env python3
from pathlib import Path
from bs4 import BeautifulSoup
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]; checks=0
allowed={'q-compact','q-standard','q-large','q-xlarge'}
bare={'compact','standard','large','xlarge'}
def check(c,m):
    global checks
    checks+=1
    if not c: errors.append(m)
for p in root.rglob('*.html'):
    s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
    # Only apply math Summative contract where the HTML actually uses assessment-question.
    qs=s.select('.assessment-question')
    if qs:
        for i,q in enumerate(qs,1):
            cls=set(q.get('class') or [])
            check(len(cls & allowed)==1, f'{p}: question {i} missing/excess q-* size class: {sorted(cls)}')
            check(not (cls & bare), f'{p}: question {i} uses bare size class: {sorted(cls & bare)}')
            prompt=q.select_one('.question-prompt')
            if prompt:
                for fig in prompt.find_all('figure'):
                    if fig.find('img'):
                        check('figure-block' in (fig.get('class') or []), f'{p}: question {i} image figure missing figure-block')
                        img=fig.find('img')
                        check('question-graph' in (img.get('class') or []), f'{p}: question {i} image missing question-graph')
                for table in prompt.find_all('table'):
                    tc=set(table.get('class') or [])
                    check(bool(tc & {'data-table','values'}), f'{p}: question {i} has unstyled/bare data table')
                check(not prompt.find('figcaption'), f'{p}: question {i} has descriptive figcaption')
print(f'RECURRING_SHELL_CHECKS={checks}')
print(f'ERRORS={len(errors)}')
for e in errors: print('ERROR:',e)
sys.exit(1 if errors else 0)
