CANONICAL RECURRING / ASSESSMENT HTML REFERENCES
================================================

These references preserve approved student-facing DOM/class structures:
- warmup_reference.html
- exit_ticket_reference.html
- progress_tracker_reference.html
- review_reference.html
- review_practice_reference.html
- summative_math_shell.html

Use a reference only when the current Framework selects that resource family/usage mode. The Framework and
Assessment Plan/Bank remain authoritative for actual content, counts, active form IDs, evidence language, paths,
and course-specific behavior.

The Summative shell intentionally contains NO historical secure questions. Populate each active form only from
the current secure Bank. Do not copy old V5/V6 content or infer form membership from a reference artifact.

LOCKED MATH SUMMATIVE SHELL DETAILS (v1.8)
------------------------------------------
- `SIZE_Q##` placeholders contain only `compact|standard|large|xlarge`; the shell supplies the required `q-` prefix.
- Image representations render through `figure-block` + `question-graph`.
- Ordinary data tables use `data-table` (or an explicitly Framework-approved styled table class).
- Descriptive figcaptions are omitted.

GENERIC RUN
Use exactly: `Carefully read PM and Run.`
The current PM package determines the operation; do not paste an older resource-specific prompt.
