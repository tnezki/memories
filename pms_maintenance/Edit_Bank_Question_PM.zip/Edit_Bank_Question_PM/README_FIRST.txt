Targeted Bank question editor. Input: complete Unit Bank + exact Bank item edit request. Output: complete updated Unit Bank.
