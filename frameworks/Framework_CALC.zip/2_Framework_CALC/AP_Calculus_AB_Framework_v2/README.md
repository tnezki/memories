# AP Calculus AB Framework v2.3

Machine-first, Framework-integrated course brain for the supplied 8-unit / 40-section AP Calculus AB course.

## What is embedded
- 8 original Unit Assessment Plans (unchanged source bytes)
- 40-section course map and pacing/classroom-flow signals
- CED-derived official AP topic titles, unit weightings, big ideas, mathematical practices, calculator/exam expectations
- compact AP Topics scoring-guide source catalog with 68 source documents, representative task excerpts, and scoring signals
- section reference packets combining Assessment Plan authority + CED + AP task models + calculus textbook page pointers
- question/task archetype menus, misconception/distractor seeds, Math Note ideas, reusable table structures, and future resource hooks
- 40 approved answer-neutral course figures generated with the authoritative graph tool
- authoritative graph tool, universal Bank finalizer, standalone MathJax v10 maintenance fixer, and shared Bank/Summative CSS references
- canonical course-file-structure and live-course-upgrade contracts

## Compact-source policy
Large raw AP Topic PDFs, textbooks, and CED are not duplicated into the ZIP. Their strongest authoring value is curated into machine-readable packets, representative AP task excerpts, scoring profiles, page pointers, source hashes, and visual pointers. This keeps the Framework portable while avoiding a thin metadata-only package.

## v2.1 Universal Bank compatibility
Upload the current Universal Bank Starter ZIP plus this Framework ZIP and use `Carefully read PM and Run.` Course identity is inferred from this Framework. Current Universal PM owns Bank counts, no-MC canonical AP Calculus response profile, Summative form/security rules, HTML/CSS, QA split, and delivery. AP source MC remains source evidence only. Practice repeats are allowed; no second-pass labels or form-wide stock suffixes.


## v2.2 final-byte reconciliation
- Standalone MathJax maintenance tool updated to `tools/~fix_mathjax_v10.py`.
- Universal Bank finalizer embeds the v10 configuration-alignment repair and runs it before the FINAL ZIP.
- HTML-producing resource builds may run the Framework v10 tool on staging output before packaging.

## v2.3 generic-run reconciliation
Use `Carefully read PM and Run.` with the current executable Base PM. The Base PM determines the operation; this Framework supplies course-specific authority.
