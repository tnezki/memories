10_Base_Pract_to_Sum_PM
=======================

THIS IS THE ONLY PM THE TEACHER NEEDS TO TRACK FOR NORMAL PRACTICE-THROUGH-SUMMATIVE UNIT BUILDS.

Upload:
- this ZIP
- current Framework ZIP
- finalized current Unit Bank ZIP

Prompt:
  Carefully read PM and Run.

It embeds the Practice, Activities, and Recurring/Assessment PMs internally.
Do not separately upload PM 5, PM 6, or PM 7 unless deliberately debugging a family.

Delivery requirement:
- every child resource ZIP separately
- plus one all-in-one unit[U]_practice_to_summative.zip using course-parent folders for drag/drop

Current refinement: v3.3 keeps the quality/anti-confusion gates and makes the master ZIP a Finder-friendly drop-in package using the deployed course-parent folders.

IMPORTANT:
This PM requires ONLY:
- this PM ZIP
- current Framework ZIP
- finalized current Unit Bank ZIP

It NEVER requires an existing course-site ZIP. If a run asks for a course-site ZIP or identifies itself as Course Bank Sync PM v1.1, the wrong PM was selected/read. Do not continue that run as a sync operation.

Review routing note: Unit Review/Review Practice are current-Unit Mastery resources. The internal Retrieval stage is a separate spiral route.

Exit Tickets now build projector Ticket A/B/C plus four normalized print/collect versions per ticket using the Anchor / Parallel A / Parallel B / Variation contract.
Systemic PM bottlenecks are reported for approval rather than silently self-modifying the authority shelf.
