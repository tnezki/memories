4A BUILD NOTES MAP v1.2
======================

PURPOSE
Design the Physics Notes instructional story BEFORE prose is written.
Sequence the best Hewitt/source-textbook images, conceptual reading beats, the already-canonical Bank EX/YTI anchors, WTC placement, vocabulary development, and Stop & Discuss processing.

FIRST TASK
READ THE CURRENT CURRICULUM PHILOSOPHY COMPLETELY.

REQUIRED INPUTS
1. This PM package
2. Current Curriculum Philosophy
3. Current Physics Framework
4. Current complete/materialized Unit Bank
5. Tools/Physics_Notes_Image_Toolkit.zip

IMPORTANT AUTHORITY SPLIT
- The Unit Bank owns canonical WTC / Example / YTI wording, values, figures, and solutions.
- The Physics Notes Image Toolkit owns the image inventory and provenance.
- 4A owns Notes sequencing/planning only.
- 4B will own final Notes prose/rendering/package mechanics.
- _question_structure.zip is NOT required for 4A; 4A does not author new Bank questions.

OUTPUT
unitN_notes_map.zip

SAVE THE ZIP, STILL ZIPPED, AT
<course>/notes/unitN_notes_map.zip

DO NOT deploy this ZIP as Notes. It is a planning checkpoint for 4B.

HARD STOP & DISCUSS VALIDATION
Before PASS, every Stop & Discuss anchor must keep source_image_ids as verified PHYS-XXXXXXXXXXXX toolkit IDs and expected_reasoning_evidence_to_listen_for as teacher-facing reasoning text. Swapped/overloaded fields fail closed.

CONTENT-STABLE BANK IDENTITY (v1.2)
4A must fingerprint the Bank by authored content, never by raw unitN_bank.zip bytes. Use the bundled ~stable_bank_fingerprint_v1.py. Primary identity is STAGE_3E_HANDOFF.json canonical_authored_content_sha256; deterministic extracted-content manifest is the documented fallback.
