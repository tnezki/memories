BUILD PROGRESS TRACKER — PILOT WORKING PM v0.1
================================================
STATUS: PILOT / WORKING — test and revise from real jobs.

CANONICAL AUTHORITY / GITHUB SNAPSHOT — HARD RULE
=================================================
GitHub is the canonical source of truth. At the start of each job:
1. Resolve the current commit of the canonical system repository once.
2. Pin that commit for the entire job; do not mix files from later commits.
3. Read `_Curriculum_Philosophy_PM.zip` FIRST from that pinned snapshot.
4. Read `_question_structure.zip` when the job authors, varies, audits, or repairs questions.
5. Read the current course Framework from the same pinned snapshot.
6. Read this PM from the same pinned snapshot.
7. Resolve any required Bank, Bank Map, CSS, tools, templates, or course-repository files from the declared canonical repository/commit for the job.
8. If a required canonical authority is missing, duplicated under conflicting names, or ambiguous, FAIL CLOSED. Do not substitute an older upload, stale chat copy, remembered version, or similarly named file.

Normal authority order by domain:
  Curriculum Philosophy -> Question Structure -> Course Framework -> PM -> Tool/CSS/template
The exact current Unit Assessment Plan embedded/identified by the Framework is authoritative for the course/unit terminology and learning/evidence architecture.
A direct teacher instruction for the current artifact may intentionally override the normal default locally. That does not automatically change the system-wide rule or upstream Bank.

PM BOUNDARY
===========
This PM owns procedure: what to fetch, validate, select, assemble, audit, and output. It does not restate a competing Philosophy, Framework, Question Structure catalog, or renderer/CSS specification.
Finished classroom artifacts may improve, rewrite, replace, add, or remove Bank-sourced wording when that makes the declared artifact better. Preserve lightweight provenance when practical. Local artifact edits do not automatically update the Bank.
Each job declares replacement/output scope. Do not alter unrelated artifacts outside that scope. Return the smallest coherent deployable result appropriate to the declared scope.


PURPOSE
Build a student/teacher Progress Tracker that reflects the exact current evidence language and mastery architecture of the course/unit.

PROCEDURE
1. Read the exact Assessment Plan first for Mastery Goals, supporting I-cans, evidence language, and any status/progress terminology.
2. Do not invent or restore obsolete tracker vocabulary from old PMs or artifacts.
3. The tracker reports/organizes evidence; it does not create a second curriculum map or redefine the Assessment Plan.
4. Use the current Framework's approved shell/CSS and course-specific print contract.
5. Treat this as a physical print artifact when the Framework says so: prioritize legibility and efficient page use. Fit the required page count rather than preserving oversized whitespace/font choices from a stale template.
6. Validate exact goal/I-can text, links, page breaks, writing space, and print rendering.

OUTPUT
Return the declared Progress Tracker replacement scope only, with repository-relative structure intact.
