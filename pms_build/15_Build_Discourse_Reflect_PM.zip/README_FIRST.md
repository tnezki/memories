BUILD DISCOURSE + REFLECTION — PILOT WORKING PM v0.1
======================================================
STATUS: PILOT / WORKING — test and revise from real jobs.

CANONICAL AUTHORITY / GITHUB SNAPSHOT — HARD RULE
=================================================
GitHub is the canonical source of truth. At the start of each job:
1. Resolve the current commit of the canonical system repository once.
2. Pin that commit for the entire job; do not mix files from later commits.
3. Read `_Curriculum_Philosophy_PM.zip` FIRST from that pinned snapshot.
4. Read `_question_structure.zip` when the job authors, varies, audits, or repairs questions.
5. Read the current course Framework from the same pinned snapshot.
6. Read this PM from the same pinned snapshot.
7. Resolve any required Bank, Bank Map, CSS, tools, templates, or course-repository files from the declared canonical repository/commit for the job.
8. If a required canonical authority is missing, duplicated under conflicting names, or ambiguous, FAIL CLOSED. Do not substitute an older upload, stale chat copy, remembered version, or similarly named file.

Normal authority order by domain:
  Curriculum Philosophy -> Question Structure -> Course Framework -> PM -> Tool/CSS/template
The exact current Unit Assessment Plan embedded/identified by the Framework is authoritative for the course/unit terminology and learning/evidence architecture.
A direct teacher instruction for the current artifact may intentionally override the normal default locally. That does not automatically change the system-wide rule or upstream Bank.

PM BOUNDARY
===========
This PM owns procedure: what to fetch, validate, select, assemble, audit, and output. It does not restate a competing Philosophy, Framework, Question Structure catalog, or renderer/CSS specification.
Finished classroom artifacts may improve, rewrite, replace, add, or remove Bank-sourced wording when that makes the declared artifact better. Preserve lightweight provenance when practical. Local artifact edits do not automatically update the Bank.
Each job declares replacement/output scope. Do not alter unrelated artifacts outside that scope. Return the smallest coherent deployable result appropriate to the declared scope.


PURPOSE
Build discussion/reflection resources that deepen or consolidate the declared learning without pretending they are Bank inventory or a new Assessment Plan.

PROCEDURE
1. Resolve the exact learning focus from the Assessment Plan/Framework and the teacher's declared artifact scope.
2. Choose discourse/reflection structures that fit the content: explain/compare/justify/critique/connect/reflect, short written synthesis, partner/group prompts, or other course-appropriate routines.
3. Do not force quantitative, vocabulary, CER, or other structures merely for variety.
4. Bank questions may inform or seed prompts, but finished discussion/reflection wording may be purpose-built for the artifact. Preserve provenance when useful.
5. Use approved recurring shells when one exists. If the requested resource is genuinely custom, use the best-fit HTML/CSS permitted by the Framework instead of forcing a recurring shell.
6. Validate accessibility, student directions, target alignment, and teacher-use practicality.

OUTPUT
Return only the declared discourse/reflection artifact scope in repository-relative structure.
