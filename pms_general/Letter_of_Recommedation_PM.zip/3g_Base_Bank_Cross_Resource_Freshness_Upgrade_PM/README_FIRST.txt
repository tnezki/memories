3g — Cross-Resource Freshness & Independence Upgrade

Use:
  current Framework + finalized Unit Bank + this PM ZIP

Prompt:
  Carefully read PM and Run.

Run this before 3h.
